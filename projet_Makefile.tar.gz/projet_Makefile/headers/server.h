#ifndef _SERVER_H
#define _SERVER_H



void list(int socket);

void list2(int socket);

void handler(int signal);

void service(int* socket);


void checkMime(char *filename, int socket);

void sendFile(char* nom_fichier, int socket);

void getFileNames(int socket, char* index_array, int size);

void checkIndex();

void fileExists();

void getIndex(int socket);

void push();

void service2(int socket);

void receiveFile(int socket);

void getClientFiles(int socket);

int main(int argc, char **argv);

#endif // !SERVER_H
